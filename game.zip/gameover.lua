gameover = {}

function gameover.load()
	gameover.wordCorrectSoFar = ""
	gameover.red = 255
	gameover.green = 255
	gameover.blue = 255
	gameover.wordRemaining = "restart"
	gameover.x = 0
	gameover.y = love.graphics.getHeight()/2 - 300

end

function gameover.draw()
	w = love.graphics.getWidth()
	love.graphics.setNewFont(100)
	love.graphics.printf("GAME OVER :(", 0, love.graphics.getHeight()/2 - 100, w, "center")
	love.graphics.print({{255, 255, 255}, gameover.wordCorrectSoFar,  {gameover.red, gameover.green, gameover.blue}, gameover.wordRemaining} , gameover.x, gameover.y + gameover.height, w, "center")
end

function gameover.keypressed(key)

end