words = {
"about",
"search",
"other",
"which",
"their",
"there",
"contact",
"business",
"online",
"first",
"would",
"services",
"these",
"click",
"service",
"price",
"people",
"state",
"email",
"health"
}

function words.getRandomWord()
	return words[math.random(1, 20)]
end